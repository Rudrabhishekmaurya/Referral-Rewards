# Referral App - Full Vite + MERN Core Project

## Folder structure

```text
Referral_App_Final/
├── Backend/
│   ├── config/db.js
│   ├── models/User.js
│   ├── Routes/Authroutes.js
│   ├── package.json
│   └── server.js
└── Frontend/
    ├── public/
    ├── src/
    │   ├── components/
    │   │   ├── Dashboard.jsx
    │   │   ├── Signin.jsx
    │   │   └── Signup.jsx
    │   ├── App.jsx
    │   ├── App.css
    │   ├── index.css
    │   └── main.jsx
    ├── index.html
    ├── package.json
    └── vite.config.js
```

## 1. MongoDB

Start local MongoDB and MongoDB Compass.

The backend uses:

mongodb://localhost:27017/referralApp

## 2. Backend

Open a terminal in `Backend`:

```bash
npm install
npm run dev
```

Expected:

```text
Server running on port 5000
MongoDB connected
```

Test in browser:

```text
http://localhost:5000/
```

## 3. Frontend

Open a second terminal in `Frontend`:

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## 4. Main referral flow

1. Rudra signs up.
2. Backend creates something like `RUDRA5832`.
3. Dashboard creates:
   `http://localhost:5173/signup?ref=RUDRA5832`
4. Amit opens the link.
5. React reads `ref`.
6. React sends the referral code with Amit's signup data.
7. Backend finds Rudra by `referralCode`.
8. Amit is saved with `referredBy: "RUDRA5832"`.
9. Rudra receives 10 points.
10. Amit cannot register again with the same email.
11. Dashboard shows referral count, points and referred users.

## Important security note

This learning/assessment version keeps passwords as plain text so the logic is easy to explain. A production application should hash passwords with bcrypt/argon2 and use proper authentication/session or JWT handling.

## Useful API tests

### Signup without referral

POST `http://localhost:5000/api/signup`

```json
{
  "name": "Rudra",
  "email": "rudra@gmail.com",
  "password": "123456"
}
```

### Signup with referral

POST `http://localhost:5000/api/signup`

```json
{
  "name": "Amit",
  "email": "amit@gmail.com",
  "password": "123456",
  "referralCode": "RUDRA5832"
}
```

### Login

POST `http://localhost:5000/api/login`

```json
{
  "email": "rudra@gmail.com",
  "password": "123456"
}
```

### Dashboard

GET:

```text
http://localhost:5000/api/user/USER_ID
```

This project includes CORS configuration so the Vite frontend at port 5173 can call the Express backend at port 5000.
