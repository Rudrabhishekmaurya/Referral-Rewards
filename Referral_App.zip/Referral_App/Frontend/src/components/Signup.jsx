import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";

function Signup() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const referralCode = searchParams.get("ref");

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: ""
  });

  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (event) => {
    setForm({
      ...form,
      [event.target.name]: event.target.value
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setMessage("");
    setLoading(true);

    try {
      const response = await fetch("http://localhost:5000/api/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ...form,
          referralCode
        })
      });

      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message);
        return;
      }

      setMessage(`Account created. Your referral code is ${data.user.referralCode}`);

      setTimeout(() => {
        navigate("/signin");
      }, 1000);
    } catch (error) {
      setMessage("Cannot connect to backend. Make sure the server is running.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="page">
      <section className="card auth-card">
        <div className="brand">REFERRAL<span>+</span></div>
        <p className="eyebrow">JOIN THE REWARDS PROGRAM</p>
        <h1>Create your account</h1>
        <p className="muted">Invite friends, earn points, and track your rewards.</p>

        {referralCode && (
          <div className="ref-banner">
            Referred by <strong>{referralCode}</strong>
          </div>
        )}

        <form onSubmit={handleSubmit} className="form">
          <label>
            Name
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Enter your name"
              required
            />
          </label>

          <label>
            Email
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              placeholder="you@example.com"
              required
            />
          </label>

          <label>
            Password
            <input
              name="password"
              type="password"
              value={form.password}
              onChange={handleChange}
              placeholder="Minimum 6 characters"
              minLength="6"
              required
            />
          </label>

          <button className="button" disabled={loading}>
            {loading ? "Creating..." : "Create Account"}
          </button>
        </form>

        {message && <p className="form-message">{message}</p>}

        <p className="switch">
          Already have an account? <Link to="/signin">Sign in</Link>
        </p>
      </section>
    </main>
  );
}

export default Signup;
