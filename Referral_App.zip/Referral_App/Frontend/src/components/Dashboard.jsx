import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Dashboard() {
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
      setMessage("Please sign in to view your dashboard.");
      return;
    }

    fetch(`http://localhost:5000/api/user/${userId}`)
      .then(async (response) => {
        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Unable to load dashboard");
        }

        return data;
      })
      .then((data) => setUser(data))
      .catch((error) => setMessage(error.message));
  }, []);

  const logout = () => {
    localStorage.removeItem("userId");
    window.location.href = "/signin";
  };

  const copyLink = async () => {
    if (!user?.referralLink) return;

    await navigator.clipboard.writeText(user.referralLink);
    setMessage("Referral link copied!");
  };

  if (!user) {
    return (
      <main className="page">
        <section className="card auth-card center-card">
          <div className="brand">REFERRAL<span>+</span></div>
          <h1>Referral Dashboard</h1>
          <p className="muted">{message || "Loading..."}</p>
          {!localStorage.getItem("userId") && (
            <Link className="button link-button" to="/signin">
              Sign In
            </Link>
          )}
        </section>
      </main>
    );
  }

  return (
    <main className="page dashboard-page">
      <section className="dashboard">
        <header className="topbar">
          <div>
            <div className="brand">REFERRAL<span>+</span></div>
            <p className="muted">Welcome back, {user.name}</p>
          </div>

          <button className="ghost-button" onClick={logout}>
            Logout
          </button>
        </header>

        <section className="hero-card">
          <div>
            <p className="eyebrow">YOUR REFERRAL CODE</p>
            <h1>{user.referralCode}</h1>
            <p className="muted">Share your link and earn 10 points for each new referral.</p>
          </div>
          <div className="code-pill">{user.points} points</div>
        </section>

        <section className="stats-grid">
          <div className="stat-card">
            <span>Total Referrals</span>
            <strong>{user.totalReferrals}</strong>
          </div>
          <div className="stat-card">
            <span>Total Points</span>
            <strong>{user.points}</strong>
          </div>
          <div className="stat-card">
            <span>Referred By</span>
            <strong>{user.referredBy || "Direct signup"}</strong>
          </div>
        </section>

        <section className="card share-card">
          <div>
            <p className="eyebrow">YOUR REFERRAL LINK</p>
            <p className="ref-link">{user.referralLink}</p>
          </div>
          <button className="button small-button" onClick={copyLink}>
            Copy Link
          </button>
        </section>

        {message && <p className="form-message">{message}</p>}

        <section className="card">
          <div className="section-heading">
            <div>
              <p className="eyebrow">ACTIVITY</p>
              <h2>People you referred</h2>
            </div>
          </div>

          {user.referrals.length === 0 ? (
            <p className="muted empty">No referrals yet. Share your link to get started.</p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {user.referrals.map((referral) => (
                    <tr key={referral._id}>
                      <td>{referral.name}</td>
                      <td>{referral.email}</td>
                      <td>
                        {new Date(referral.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </section>
    </main>
  );
}

export default Dashboard;
