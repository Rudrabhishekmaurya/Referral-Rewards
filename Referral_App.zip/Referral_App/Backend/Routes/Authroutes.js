const express = require("express");
const User = require("../models/User");

const router = express.Router();

const createReferralCode = (name) => {
  const cleanName = name.toUpperCase().replace(/\\s+/g, "");
  const randomNumber = Math.floor(1000 + Math.random() * 9000);
  return `${cleanName}${randomNumber}`;
};

// SIGNUP
router.post("/signup", async (req, res) => {
  try {
    const { name, email, password, referralCode } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        message: "Name, email and password are required"
      });
    }

    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(400).json({
        message: "Email already registered"
      });
    }

    let newReferralCode = createReferralCode(name);

    while (await User.findOne({ referralCode: newReferralCode })) {
      newReferralCode = createReferralCode(name);
    }

    let referredBy = null;
    let referrer = null;

    if (referralCode) {
      referrer = await User.findOne({ referralCode });

      if (referrer) {
        referredBy = referrer.referralCode;
      }
    }

    const user = new User({
      name,
      email,
      password,
      referralCode: newReferralCode,
      referredBy
    });

    await user.save();

    if (referrer) {
      referrer.points += 10;
      await referrer.save();
    }

    res.status(201).json({
      message: "User created successfully",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        referralCode: user.referralCode,
        referralLink: `http://localhost:5173/signup?ref=${user.referralCode}`,
        referredBy: user.referredBy,
        points: user.points
      }
    });
  } catch (error) {
    res.status(500).json({
      message: "Error creating user",
      error: error.message
    });
  }
});

// LOGIN
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        message: "Email and password are required"
      });
    }

    const user = await User.findOne({ email });

    if (!user || user.password !== password) {
      return res.status(400).json({
        message: "Invalid email or password"
      });
    }

    res.json({
      message: "Login successful",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        referralCode: user.referralCode,
        referralLink: `http://localhost:5173/signup?ref=${user.referralCode}`,
        referredBy: user.referredBy,
        points: user.points
      }
    });
  } catch (error) {
    res.status(500).json({
      message: "Login error",
      error: error.message
    });
  }
});

// DASHBOARD
router.get("/user/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        message: "User not found"
      });
    }

    const referrals = await User.find({
      referredBy: user.referralCode
    })
      .select("name email createdAt")
      .sort({ createdAt: -1 });

    res.json({
      name: user.name,
      email: user.email,
      referralCode: user.referralCode,
      referralLink: `http://localhost:5173/signup?ref=${user.referralCode}`,
      referredBy: user.referredBy,
      points: user.points,
      totalReferrals: referrals.length,
      referrals
    });
  } catch (error) {
    res.status(500).json({
      message: "Dashboard error",
      error: error.message
    });
  }
});

module.exports = router;
